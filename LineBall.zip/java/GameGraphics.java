import data.Object;

import javax.swing.*;
import java.awt.*;


public class GameGraphics extends JFrame {
    GameData data;
    private Object traingle;

    public GameGraphics() throws HeadlessException {
        Draw draw = new Draw();
        add(draw);

        this.data = null;

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1080,720);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void render(GameData data) {
        this.data = data;
        repaint();
    }

    class Draw extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            g.setColor(data.getBall().getColor());
            g.fillOval(data.getBall().getX(), data.getBall().getY(), data.getBall().getWidth(), data.getBall().getHeight());
            g.setColor(data.getTraingle().getColor());
            if (!data.getTraingle().draw()) {
            g.drawLine(data.getTraingle().getX(),data.getTraingle().getY(),data.getTraingle().getX2(),data.getTraingle().getY2());

        }
    }
}}

package data;

public enum Direction {
    UP, DOWN, LEFT, RIGHT
}

import data.Ball;
import data.Direction;
import data.Object;

import java.awt.*;

public class GameData {
    private Ball ball;
    private Object traingle;

    public void update() {
        ball.move(2, Direction.RIGHT);traingle.move(0, Direction.LEFT);
        if (traingle.getX2() == ball.getX()+50){
            System.out.println("###########collision!##############");
            traingle.setDraw(false);

        }
    }


    public void initialize() {
        ball = new Ball(20, 100, 50, 50, Color.red);
        traingle = new Object(200, 200, 100, 200,Color.BLUE);

    }

    public Ball getBall() {
        return ball;
    }
    public Object getTraingle() {
        return traingle;
    }
}

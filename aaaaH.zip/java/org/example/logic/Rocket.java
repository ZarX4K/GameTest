package org.example.logic;

public class Rocket extends Entity {

    private int velocityX;
    private int velocityY;
    private int playerCordX;
    private int playerCordY;


    public Rocket(int x, int y, int velocityX, int velocityY,int playerCordX,int playerCordY, String url) {
        super(x, y, url);
        this.velocityX = velocityX;
        this.velocityY = velocityY;
        this.playerCordX = playerCordX;
        this.playerCordY = playerCordY;
    }

    public void move() {
        coord.x += velocityX;
        coord.y += velocityY;
    }
    public void PlayerCord() {
        coord.x = playerCordX;
        coord.y = playerCordY;
    }

}
package org.example;

public class Game {
    public static void main(String[] args) {
        GameGraphics frame = new GameGraphics();
    }
}
